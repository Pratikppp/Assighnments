#include<iostream>
using namespace std;
class loan
{
	private:
		double principle;
		double period;
		
   
	public:
		double rate;
		void setprinciple(double pri)
		{
		principle=pri;
		}
		double getprinciple()
		{
			return principle;
		}

		void setperiod(double prd)
		{
		period=prd;
		}
		double getperiod()
		{
			return period;
		}

		virtual double getrate()=0;

		 double getemi(double rate)
		{
			double emi;
			emi=principle*(1+rate*period/100)/(12*period);
			return emi;
		}



};

class personalloan:public loan
{
	public:
		
		double getrate()
		{
			if(loan::getprinciple()<500000)
			return rate=15;
			else 
			return rate=16;
		}

};

class homeloan:public loan
{
	public:

		double getrate()
		{
			if(loan::getprinciple()<2000000)
			return rate=10;
			else 
			return rate=11;
		}

};

int main()
{
	int principle,period;
	int a,b,c;
	cout<<"enter amount and period"<<endl;
	cin>>principle>>period;

	cout<<"press 1 for personal loan and 2 for home loan"<<endl;
	cin>>a;
	if(a==1)
	{
		personalloan pl;
		pl.setprinciple(principle);
		pl.setperiod(period);
                c=pl.getrate();
		b=pl.getemi(c);
			cout<<"your emi for personal loan is"<<b<<endl;
	}


	else if(a==2)
	{
		homeloan hl;
		hl.setprinciple(principle);
		hl.setperiod(period);
                c=hl.getrate();
		b=hl.getemi(c);
			cout<<"your emi for home loan is"<<b<<endl;
	}
	return 0;
}
