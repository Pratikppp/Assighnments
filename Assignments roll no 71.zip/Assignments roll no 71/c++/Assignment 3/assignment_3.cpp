#include<iostream>
using namespace std;
 
class patient
{
	private:
		int pid;
		char pname;
		int bedtype;
		int Days;

	public:
	
	
		//int amount;
		patient(){
		
		}

		//int price;

		patient(int id,char name, int btype, int days)
		{
			pid=id;
			pname=name;
			bedtype=btype;
			Days=days;
		}
		virtual double getbillamt()
		{   
			double amount = 0;
			double price = 0;
			if(bedtype==1)
				price=500;
			else if(bedtype==2)
				price=350;
			else if(bedtype==3)
				price=200;
			
			amount= (Days*price);
			return amount;
		}

};


class inhousepatient:public patient
{
	private:
	int discount;
	double finalamount;


	public:
		
	inhousepatient() : patient()
	{
	}

	inhousepatient(int id,char name, int btype, int days, int discount = 5) : patient(id, name, btype, days)
	{
              discount = 5;

	}
	double getbillamt()

	{
		double  amount=patient::getbillamt();
		if(amount>5000)
			 finalamount = amount - (0.05*amount);
		 return finalamount;
	}


};




	int main()
{
	int id,btype,days;
	double x,d;
	char name;
	cout<<"enter the id,bed type, and days"<<endl;
	cin>>id>>btype>>days;

	cout<<"enter the name"<<endl;
	cin>>name;
	patient p1(id,name,btype,days);
	x=p1.getbillamt();
	cout<<"the amount is"<<x<<endl;
	inhousepatient p2(id,name,btype,days);
	d=p2.inhousepatient::getbillamt();
	cout<<"your amount with discount is"<<d<<endl;

	return 0;
}








