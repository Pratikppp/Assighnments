class Loan
{
	private:
		double Principle;
		int Period;
	public:
		void SetPrinciple(double p)
		{
			Principle=p;
		}
		double GetPrinciple()
		{
			return Principle;
		}
		void SetPeriod(int a)
		{
			Period=a;
		}
		int GetPeriod()
		{
			return Period;
		}
		virtual double GetRate()=0;
		double GetEmi()
		{
			return Principle*(1+GetRate()*Period/100)/(12*Period);
		}
};
class Taxable
{
	public:
		virtual double GetTax()=0;
};
class Discountable
{
	public:
		virtual double GetDiscount()=0;
};


class PersonalLoan:public Loan,public Taxable
{

	private:
		double Rate;
		double Amount=Loan::GetPrinciple();

	public:
		double GetRate()
		{
			if(Amount<500000)
				return Rate=15;
			else 
				return Rate=16;
		}
		double GetTax()
		{
			if(Amount>2000000)
			       return 0.1;
			else 
				return 0.07;
		}
};

class HomeLoan:public Loan,public Discountable
{
	private:
		double Rate;
		double Amount=Loan::GetPrinciple();
	public:
		double GetRate()
		{
			if(Amount<=2000000)
				return Rate=10;
			else 
				return Rate=11;
		}
		double GetDiscount()
		{
			if(Amount>2500000)
				return 0.2;
			else
				return 0.1;
		}


};


