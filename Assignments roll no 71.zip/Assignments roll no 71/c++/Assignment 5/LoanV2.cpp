#include"LoanV2.h"
#include<iostream>
#include<cstdio>
using namespace std;
double compute(Loan *p)
{
	double EMI=p->GetEmi();
	auto HT=dynamic_cast<Discountable*>(p);
	auto PD=dynamic_cast<Taxable*>(p);
	if(HT)
		return EMI-EMI*HT->GetDiscount();
	else
		return EMI+EMI*PD->GetTax();

}

int main(void)
{
	double Amount=0;
	int Period=0;
	int choice;
	cout<<"Enter the Amount of Loan: "<<endl;
	cin>>Amount;
	cout<<"Enter the No. of year: "<<endl;
	cin>>Period;
	PersonalLoan pl;
	HomeLoan hl;
	cout<<"Enter the Loan Type"<<endl
	    <<"1.Personal Loan"<<endl
	    <<"2.Home Loan"<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:
			pl.SetPrinciple(Amount);
			pl.SetPeriod(Period);
			cout<<"The Your Monthly EMI is: "<<compute(&pl)<<endl;
			break;
		case 2:
			hl.SetPrinciple(Amount);
			hl.SetPeriod(Period);
			cout<<"Your Monthly EMI is: "<<compute(&hl)<<endl;
			break;
		default:
			cout<<"Invalid Entry."<<endl;
	}
}


