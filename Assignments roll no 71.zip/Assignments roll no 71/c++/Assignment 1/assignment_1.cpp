#include<iostream>
#include<cmath>
using namespace std;


class Invest
{
	private:
		double amt;
		int period;
		int rate;

	public:
		Invest(double p, int n)	
		{
			amt=p;
			period=n;
			

		}
	
		void check_rate()
		{
			if(amt<=10000)
				rate=8;
			else if (amt>=10001&&amt<=50000)
				rate=9;
			else //amount will be greater than 50k
				rate=10;
		}

		void check_period()
		{
			if (period>5)
				rate++;
		}

		bool  getint()
		{
			int y;
			cout<<"press 1 for Coumpound Interest"<<endl;
			
			cout<<"press 2 for Simple Interest"<<endl;
			cin>> y ;
			if (y==1)
				return true;
			if (y==2)
				return false;
		}

		double simple_interest()
		{
			
			return ((amt*period*rate)/100);
		}
		
		double a;
		double compound_interest()
		{
			
			a=amt*pow((1+(rate/100)),period);
			return (a-amt);
		}

};







int main()
{
	double p;
	int n;
	double k,j;
	int g;
	cout<<"enter amount and period"<<endl;
	cin>>p>>n;
	Invest x(p,n);
	x.check_rate();
	x.check_period();
	g=x.getint();
	if(g==0)
	{	k=x.simple_interest();
		cout<<"si is "<<k;
	}
	
	else if(g==1)
	{	j=x.compound_interest();
		cout<<"ci is "<<j;
	}
		return 0;
}


























