#include<cstdio>

class Money
{
	private:
		int Rupees;
		int Paise;
	public:
		Money(int x=0, int y=0)

		{
			Rupees=x;
			Paise=y;
		//	printf("The instances are initialized\n");
		}
		Money(Money& m)
		{
			Rupees=m.Rupees;
			Paise=m.Paise;
		//	printf("The instances are coppies to another object\n");
		}
		void Calculate()
		{
			Rupees=Rupees+Paise/100;
			Paise=Paise%100;
		}
		int TotalMoney() const
		{
			return 100*Rupees+Paise;
		}
		void Print() const
		{
			printf("Total Rupees: %d and Paise: %d\n",Rupees,Paise); 
			printf("Total Paise %d\n",TotalMoney());
		}
                Money operator+(const Money& info)
		{
			Money Temp;
			Temp.Rupees=Rupees+info.Rupees;
			Temp.Paise=Paise+info.Paise;
			return Temp;
		}
		~Money()
		{
		//	printf("The instances are finalized\n");
		}
};

