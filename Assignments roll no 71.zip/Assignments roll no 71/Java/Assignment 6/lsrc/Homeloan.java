package loan;
public class Homeloan extends Loan {
	public void getRate() {
		if(getPrinciple()<2000000)
			rate=10;
		else 
			rate=11;
	}
}
