package loan;
public class Personalloan extends Loan {
	public void getRate() {
	if (getPrinciple()<500000)
		rate=15;
	   else
	   rate=16;
	}









}	

