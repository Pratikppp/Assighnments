package loan;
public abstract class Loan {
	private double principle;
	private double period;
	double rate;
	
	public Loan() {
	principle=10000;
	period=2;
	}

	public void setPrinciple(double pri) {
		principle=pri;
	}
	public double getPrinciple() {
		return principle;
	}

	public void setPeriod(double prd) {
		
		period=prd;
	}
	public double getPeriod() {
		return period;
	}
	public abstract void getRate(); 
	public double getEmi() {
		double emi=principle*(1+rate*period/100)/(12*period);
		return emi;
	}
}
	








