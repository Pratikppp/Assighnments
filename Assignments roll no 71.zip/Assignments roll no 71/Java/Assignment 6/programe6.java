import loan.*;
import java.util.*;
class Programe6 {
	public static void main(String[] args) {
		
		
		Scanner sc=new Scanner(System.in);
		
		System.out.printf("enter amount and period%n");
		
		double principle=sc.nextDouble();
		double period=sc.nextDouble();
		
		System.out.printf("enter 1 for personal loan and 2 for home loan%n");
		
		double a=sc.nextDouble();

		if(a==1) {
			Loan pl= new Personalloan();
			pl.setPrinciple(principle);
			pl.setPeriod(period);
			pl.getRate();
			double b=pl.getEmi();
			System.out.printf("the emi for personal loan is %.2f ",b);
		}


		
		if(a==2) {
			Loan hl= new Homeloan();
			hl.setPrinciple(principle);
			hl.setPeriod(period);
			hl.getRate();
			double b=hl.getEmi();
			System.out.printf("the emi for home loan is %.2f ",b);
		}

	}
}







