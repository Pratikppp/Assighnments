class Pratik {
	public static void main(String[] args) {
boolean a,b,c;
int d,e,f;
		a=MathUtil.isEven(20);
			if(a==true)
			System.out.printf("the number 20 is even%n");
			else
			System.out.printf("the number 20 is not even%n");

		b=MathUtil.isOdd(11);

			if(b==true)
			System.out.printf("the number 11 is odd%n");
			else
			System.out.printf("the number 11 is not odd%n");

		c=MathUtil.isPrime(17);

			if(c==true)
			System.out.printf("the number 17 is prime%n");
			else
			System.out.printf("the number 17 is not prime%n");



		d=MathUtil.countPrime(1,100);
			System.out.printf("total prime numbers in 1 and 100 are %d%n",d);

		e=MathUtil.reverse(12345);
			System.out.printf("the reverse number 12345 is %d%n",e);

		f=MathUtil.digitCount(12345);
			System.out.printf("ther total number of digits in 12345 are %d%n",f);

	}



}

