class MathUtil {
	public static boolean isEven(int a) {
		if(a%2==0)
			return true;
		else 
			return false;
	}

	
	public static boolean isOdd(int b) {
		if(b%2==0)
			return false;
		else 
			return true;
	}

	public static boolean isPrime(int c) {
		int count=0;
		int i;
		for(i=2;i<c;i++)
		{
			if(c%i==0)
				return false;
			else
				continue;
		}
			return true;


	}

	public static int countPrime(int a, int b) {
		int count=0;
		int i;
		for(i=2;i<=b;i++)
		{
			if(isPrime(i))
				count++;
			
				
		}
			return count;
	}		

	
	public static int reverse(int a) {
		int rev=0;
		int i,r;
		for(i=0;i<5;i++)
		{
			r=a%10;
			rev=rev*10+r;
			a=a/10;
		}
		return rev;
	}

	public static int digitCount(int a) {
		int count=0;
		while(a!=0)
		{
			a=a/10;
				count++;
		}
		return count;
	}


	}






















