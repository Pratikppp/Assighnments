package edu.met.banking;
public interface Resetable{
	public void reset();
}
	
