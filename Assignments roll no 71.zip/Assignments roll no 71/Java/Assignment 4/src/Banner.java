package banner;

public class Banner {
	public float width;
	public float height;
	 
	public Banner(){
	width=150;
	height=200;
	}

	public boolean Resize(float one, float two) {
		if(one>two)
		{
			width=one;
			height=two;
			return true;
		}
		return false;
	}
	public void Resize(float s) {
		Resize(s,s);
	}
	
	public float Area() {
	       return width*height;	
	}
}

