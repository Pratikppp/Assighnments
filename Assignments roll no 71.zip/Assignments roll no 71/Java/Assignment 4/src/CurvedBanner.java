package banner;

public class CurvedBanner extends Banner {
	public float radius;
	public CurvedBanner(float radi) {
		super();
		radius=radi;
	}
	public float Area() {
		return super.Area()-0.86f*radius*radius;
	}
}

	

