import java.util.*;
import banner.*; 
class Program4
{
	public static double bannerPrice(Banner info, int copies){
		double rate=copies<5?0.8:0.75;
		return copies*rate*info.Area();
	}

	public static void main(String[]args)
	{	
	Scanner sc=new Scanner(System.in);

		
	System.out.println("enter height");
	float height=sc.nextInt();

	System.out.println("enter width");
	float width=sc.nextInt();

	System.out.println("enter no of copies");
	int n=sc.nextInt();
	
	Banner a=new Banner();
	a.Resize(width,height);
	System.out.printf("Total price for regular banner=%2f\n",bannerPrice(a,n));





       Banner b=new CurvedBanner(0.5f);
       b.Resize(width,height);

	System.out.printf("Total price for special banner=%2f\n",bannerPrice(b,n));
}
}

