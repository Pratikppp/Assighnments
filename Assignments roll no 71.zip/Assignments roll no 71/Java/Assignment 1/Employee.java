class Employee {
	int eid;
	int eage;
	int ehrs;
	double erate;

	
	public Employee(int id, int age,int hrs, double rate)
		{
		        eid=id;
	      		eage=age;
			ehrs=hrs;
			erate=rate;
				
		}
				
	public double getIncome() {
		int ot=ehrs-180;
		if(ot>0)
	return ehrs*erate+ot*100;

		else 
			return ehrs*erate; 
	
	
	
	}
	public void printEmployee() {
	
	System.out.printf("employee id is %d%n",eid);
	System.out.printf("employee age is %d%n",eage);
	System.out.printf("employee hours is %d%n",ehrs);
	System.out.printf("employee rate is %f%n",erate);
	
	
	}





}


















