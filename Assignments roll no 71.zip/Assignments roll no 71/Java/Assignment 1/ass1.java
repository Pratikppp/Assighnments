class Emp {
	public static void main(String[] args) {
		int id= Integer.parseInt(args[0]);

		int age= Integer.parseInt(args[1]);
		int hrs= Integer.parseInt(args[2]);
		double rate= Double.parseDouble(args[3]);
		Employee e1= new Employee(id,age,hrs,rate);
		double a=e1.getIncome();
		e1.printEmployee();
		System.out.printf("your income is %f",a);
	}
}



