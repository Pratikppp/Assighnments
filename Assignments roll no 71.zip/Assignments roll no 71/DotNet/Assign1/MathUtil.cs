
class MathUtil
{
    

    public static bool IsEven(int num)
    {
        if (num % 2 == 0)
            return true;
        return false;
    }

    public static bool IsOdd(int num)
    {
        if (num % 2 != 0)
            return true;
        return false;
    }

    public static bool IsPrime(int num)
    {
        if (num <= 1)
            return false;

        if( num == 2)
            return true;

        if(num == 3)
            return true;

        if(IsEven(num))
            return false;

        if(IsOdd(num))
        {
            for(int i = 3; i*i<= num; i +=2)
            {
                if(num %i == 0)
                return false;
            }
        }
        return true;
        
    }

    public static int reverseNumber(int num)
    {
        int i ,sum =0;
        do
        {
            i = num % 10;
            sum = sum*10 +i;
            num = num /10;
        }while(num != 0);
        return sum;
    }

    public static int digitCount(int num)
    {
        int a,b,c;
        
        a = 1;
        b = num;
        c =0;

        do
        {
            a = a* 10;
            c =c + 1;
        }while(a <=b);

        return c;

    }


}
