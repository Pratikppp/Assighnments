﻿using System.Runtime.CompilerServices;

int Limit=int.Parse(args[0]);
var obj=new OddEven(Limit);

Thread Child= new Thread(()=>{
    obj.Even();
});
Child.Start();
obj.Odd();
Child.Join();

class OddEven
{
    public int Number{get; set;}
    public OddEven(int n)
    {
        Number=n;
    }
    [MethodImpl(MethodImplOptions.Synchronized)]
    public void Even()
    {
        int n=0;
        while(n!<Number+1)
        {
            if(n%2==0)
                Console.WriteLine("The Child thread {0} print Even Number {1}",Thread.CurrentThread.ManagedThreadId,n);
            ++n;
            Monitor.Wait(this);
            Monitor.Pulse(this);
        }

    }

    public void Odd()
    {
        lock(this)
        {
        int n=0;
        while(n!<Number+1)
        {
            if(n%2!=0)
                Console.WriteLine("The Main thread {0} print Even Number {1}",Thread.CurrentThread.ManagedThreadId,n);
            ++n;
            Monitor.Pulse(this);
            Monitor.Wait(this);
        }
    

    }


}
}