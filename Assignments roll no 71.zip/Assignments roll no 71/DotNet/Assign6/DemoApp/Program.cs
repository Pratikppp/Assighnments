﻿using System.Reflection;
using MetTour;

public delegate double Rent(int days, int NoOfPerson);

class program
{
    public static double GetTotalTourExpense(double tot, int tax)
    {
        return tot-tot*tax/100;
    }
    public static void Main(string[] args)
    {
        int Days=int.Parse(args[0]);
        int NoOfPerson=int.Parse(args[1]);
        Type t=Type.GetType(args[2]);
        MethodInfo scheme=t.GetMethod(args[3]);

        object obj=Activator.CreateInstance(t);
        Rent cal=scheme.CreateDelegate<Rent>(obj);

        LuxuryTaxAttribute lb=scheme.GetCustomAttribute<LuxuryTaxAttribute>();
        int tax=lb?.Value ?? 0;
        
        double total=cal(Days, NoOfPerson);
        
        Console.WriteLine("Welcome to AirLines");
        Console.WriteLine("The total Expense for Tour is:  {0}", GetTotalTourExpense(total,tax));
        Console.WriteLine("Thank your for Visiting!");   

    }
}