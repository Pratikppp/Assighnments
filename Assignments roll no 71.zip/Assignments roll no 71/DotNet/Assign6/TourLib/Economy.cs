namespace MetTour;

public class EconomyTour
{
public double GetDaysRent(int days, int NoOfPerson)
{
    return 500*days*NoOfPerson;
}

}