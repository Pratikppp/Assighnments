namespace MetTour;

[AttributeUsage(AttributeTargets.Method)]

public class LuxuryTaxAttribute : Attribute
{
    public int Value{get;set;}

    public LuxuryTaxAttribute(int val=8)
    {
        Value=val;
    }
}
