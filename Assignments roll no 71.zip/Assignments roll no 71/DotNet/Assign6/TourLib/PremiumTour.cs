namespace MetTour;

public class PremiumTour
{
    [LuxuryTaxAttribute(15)]
    public double GetDaysRentForCommon(int days, int NoOfPerson)
    {
        double total=1200*days*NoOfPerson;
        if(Days>6)
            total+=total-100*NoOfPerson*Days;
        if(NoOfPerson>4)
            total+=total-100*NoOfPerson*Days;
        return total;
    }
    
    [LuxuryTaxAttribute(Value=11)]
    public double GetDaysRentForWomen(int days, int NoOfPerson)=>GetDaysRentForCommon(days,NoOfPerson)-NoOfPerson*200;
    
    public double GetDaysRentForSenior(int days, int NoOfPerson)=>GetDaysRentForCommon(days,NoOfPerson)-NoOfPerson*200;
    


}