namespace Dac;
public abstract class Sequence
{
    private double total=0;

    public abstract double Next();

    public double Sum(int count)
    {
        for(int i=1; i<=count; ++i)
        {
            total+=Next();
        }
        return total;
    }
}