namespace Dac;
public interface IResetable
{
    public void Reset();
}