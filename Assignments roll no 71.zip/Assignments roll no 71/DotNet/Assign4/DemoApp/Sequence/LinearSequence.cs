namespace Dac;

public class LinearSequence : Sequence
{
    public double Current {set; get;}
    public double Step {set;get;}

    public LinearSequence()
    {
        Current=5;
        Step=3;
    }

    public override double Next()
    {
        double Term=Current;
        Current+=Step;
        return Term;
    }
}

