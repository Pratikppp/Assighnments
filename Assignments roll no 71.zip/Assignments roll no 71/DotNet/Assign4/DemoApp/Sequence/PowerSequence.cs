namespace Dac;

public class PowerSequence : Sequence, IResetable
{
    public double Current { get; set;}
    public double Factor { get; set;}

    public override double Next()
    {
        double Term=Current;
        Current*=Factor;
        return Term;
    }

    public PowerSequence()
    {
        Current=1;
        Factor=5;
    }

    public  void Reset()
    {
        Current=1;
    }

}