﻿using Dac;
class Program
{

    public static double Compute(Sequence info, int Count)
    {
        if(info is PowerSequence p)
                p.Reset();
        return  info.Sum(Count)/Count; 
    } 
    public static void Main(string[] args)
    {   
        int LCount=int.Parse(args[0]);
        int SCount=int.Parse(args[1]);
        Sequence ls= new LinearSequence();
        Sequence ps= new PowerSequence();


        Console.WriteLine($"The Sum of Linear Sequence is {Compute(ls,LCount)}");
        Console.WriteLine($"The Sum of Power Sequence is {Compute(ps,SCount)}:");
    }
}
