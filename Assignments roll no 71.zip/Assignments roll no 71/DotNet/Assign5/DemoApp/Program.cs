﻿using BankLib;
{
   {
     double p=double.Parse(args[0]);
     double n=double.Parse(args[1]);
     //double rate=double.Parse(args[2]);

     //Console.WriteLine("Enter Principle Amount {0)", );
       

     //Console.WriteLine("Enter the Period {0}", );

     PersonalLoan P=new PersonalLoan(p, n);
      var pri = Banker.openPersonalLoan();


       HomeLoan H=new HomeLoan( p, n);
     var home= Banker.openHomeLoan();


    Console.WriteLine("Calculated Personal Loan is: {}",P.);
    Console.WriteLine("Calculated HomeLoan is: {0}",);
    Console.WriteLine("Calculated  EMI is: {}",P.);
    Console.WriteLine("Calculated HomeLoan is: {0}",);

   }
}