namespace BankLib;

 sealed public class PersonalLoan :Loan

{

public override double GetRate()
   {
        if (principle<=500000)
      {
        return 15;
      }
        else
            return 16;
    }

public  double Tax()
    {
         return (principle >2000000? 0.9*principle :principle);
    }

}