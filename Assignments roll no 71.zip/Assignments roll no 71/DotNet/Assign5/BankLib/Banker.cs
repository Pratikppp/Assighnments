namespace BankLib;

public static class Banker
{

  public static Loan openPersonalLoan()
  {
       var Person = new PersonalLoan();
       return Person;
  }
public static Loan openHomeLoan()

{
  HomeLoan home = new HomeLoan();

  return home;

}
}