using BankLib;

interface Discountable
{
    public double Discount();
}