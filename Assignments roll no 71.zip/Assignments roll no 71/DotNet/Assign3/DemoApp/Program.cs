﻿using Shop;
class Program
{
    public static double Compute(Banner info,int copies)
    {
        double rate=(copies>5)?0.86:0.75;
        return info.BannerArea()*rate*copies;
    }

    public static void Main(string[] args)
    {
        int n=int.Parse(args[0]);
        int width=int.Parse(args[1]);
        int height=int.Parse(args[2]);
        if(args.Length==3)
        {
            Banner b=new Banner(width,height);
            Console.WriteLine("The total Expense of your normal banner is: {0:0.00}",Compute(b, n));
        }
        else
        {
            int radius=int.Parse(args[3]);
            CurvedBanner cb= new CurvedBanner(radius,width,height);
            Console.WriteLine("The total Expense of your Curved banner is: {0:0.00}",Compute(cb, n));
        }


    }
}
