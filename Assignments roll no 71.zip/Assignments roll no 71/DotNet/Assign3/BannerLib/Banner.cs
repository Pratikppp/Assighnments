namespace Shop;
public class Banner
{
    public int Width {get; set;}
    public int Height {get; set;}

    public Banner(int w, int h) 
    {
        Width=w;
        Height=h;
    }

    public void Resize(int w, int h)
    {
        if(h>w)
            throw new IllegalDiamensionException();
        Height=h;
        Width=w;
    }

    public virtual double  BannerArea()=>Width*Height;
    

}