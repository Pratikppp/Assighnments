public class IllegalDiamensionException : ApplicationException
{

}