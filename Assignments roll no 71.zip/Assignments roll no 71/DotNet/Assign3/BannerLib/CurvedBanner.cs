namespace Shop;

public class CurvedBanner : Banner
{
    public int Radius {get; set;}

    public CurvedBanner(int r, int w, int h): base(w,h)
    {
        Radius=r;
    }

    public override  double BannerArea()=>base.BannerArea()-0.86*Radius*Radius;
    
}